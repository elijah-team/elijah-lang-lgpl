package tripleo.elijah.util;

public class NotImplementedException extends RuntimeException {
public NotImplementedException() {
	int y=2;
}

public static void raise() {
	int y=2;
	
}
}

