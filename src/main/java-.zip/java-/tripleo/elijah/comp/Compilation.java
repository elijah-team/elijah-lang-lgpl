package tripleo.elijah.comp;

import java.util.List;

import tripleo.elijah.IO;
import tripleo.elijah.util.NotImplementedException;

public class Compilation {

	public IO io;

	public Compilation(ErrSink eee, IO io) {
		// TODO Auto-generated constructor stub
		throw new NotImplementedException();
	}

	public void feedCmdLine(List<String> args) {
		// TODO Auto-generated method stub
		throw new NotImplementedException();
	}

}
