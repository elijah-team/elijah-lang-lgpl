package tripleo.elijah.comp;

import tripleo.elijah.gen.CompilerContext;
import tripleo.elijah.gen.nodes.ImportNode;

public class GenBuffer {

	public void GenImportStmt(CompilerContext cctx, ImportNode impn) {
		// TODO Auto-generated method stub
		
	}

	public void InitMod(CompilerContext cctx, String string) {
		// TODO Auto-generated method stub
		
	}

}
