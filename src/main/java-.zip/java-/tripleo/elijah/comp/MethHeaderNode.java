package tripleo.elijah.comp;

import tripleo.elijah.lang.OS_Type;

public class MethHeaderNode {
	OS_Type returnType;
}
