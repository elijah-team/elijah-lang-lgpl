package tripleo.elijah.comp;

public class ErrSink {

}

//
//
//
