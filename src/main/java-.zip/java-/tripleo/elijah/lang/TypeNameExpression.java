package tripleo.elijah.lang;


/*
 * Created on Sep 1, 2005 8:10:27 PM
 * 
 * $Id$
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class TypeNameExpression extends AbstractExpression {

	public TypeNameExpression(TypeName aVr) {
		// TODO Auto-generated constructor stub
	}

}

