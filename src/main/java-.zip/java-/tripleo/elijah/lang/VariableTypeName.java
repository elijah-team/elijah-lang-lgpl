/*
 * Created on Sep 1, 2005 4:55:12 PM
 * 
 * $Id$
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package tripleo.elijah.lang;


public class VariableTypeName extends AbstractTypeName implements TypeName {

	public TypeName typeName(String aS) {
		// TODO Auto-generated method stub
		return null;
	}

	public TypeName typeof(String aS) {
		// TODO Auto-generated method stub
		return null;
	}

	public TypeName returnValue() {
		// TODO Auto-generated method stub
		return null;
	}

	public void type(int aI) {
		// TODO Auto-generated method stub

	}

	public TypeNameList argList() {
		// TODO Auto-generated method stub
		return null;
	}

	public void set(TypeModifiers aModifiers) {
		// TODO Auto-generated method stub
		
	}

}

