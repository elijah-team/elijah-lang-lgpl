// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ExpressionWrapper.java

package tripleo.elijah.lang;

import tripleo.elijah.lang.*;

public class ExpressionWrapper extends AbstractExpression implements
		IBinaryExpression {

	public ExpressionWrapper() {
	}
}
