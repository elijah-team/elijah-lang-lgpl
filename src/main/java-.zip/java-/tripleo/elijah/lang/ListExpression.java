/*
 * Created on Sep 1, 2005 8:28:55 PM
 * 
 * $Id$
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package tripleo.elijah.lang;


public class ListExpression extends AbstractExpression {

	public ExpressionList contents() {
		return contents;
	}

	ExpressionList contents=new ExpressionList();
}
