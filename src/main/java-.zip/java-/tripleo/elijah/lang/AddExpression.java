// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AddExpression.java

package tripleo.elijah.lang;

// Referenced classes of package pak:
//			AbstractExpression

public class AddExpression extends AbstractExpression {

	public AddExpression() {
	}

	public String repr_() {
		return "AddExpression";
	}
}
