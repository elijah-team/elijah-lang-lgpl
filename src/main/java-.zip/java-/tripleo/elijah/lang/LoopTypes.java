// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LoopTypes.java

package tripleo.elijah.lang;

public interface LoopTypes {

	public static final int WHILE = 2;

	public static final int DO_WHILE = 1;
}
