/*
 * Created on Sep 1, 2005 6:47:16 PM
 * 
 * $Id$
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package tripleo.elijah.lang;


public class ConstructExpression extends AbstractExpression implements StatementItem {

	public ConstructExpression(Scope aScope) {
	}
}
