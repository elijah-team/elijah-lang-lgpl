package tripleo.elijah.lang;

public interface OS_Element {

}
