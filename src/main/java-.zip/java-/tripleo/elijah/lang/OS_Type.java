/**
 * 
 */
package tripleo.elijah.lang;

/**
 * @author SBUSER
 *
 */
public class OS_Type {

}
