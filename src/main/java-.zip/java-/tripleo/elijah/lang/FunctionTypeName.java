// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   FunctionTypeName.java

package tripleo.elijah.lang;

// Referenced classes of package pak2:
//			AbstractTypeName, TypeNameList, TypeName

public class FunctionTypeName extends AbstractTypeName {

	public FunctionTypeName() {
	}

	public TypeNameList argList() {
		return null;
	}

	public TypeName returnValue() {
		return null;
	}

	public TypeName typeName() {
		return null;
	}

	public TypeName typeof(String aXy) {
		return null;
	}

	public void type(int i) {
	}

	public TypeName typeName(String aTypeName) {
		return null;
	}

	public void set(TypeModifiers aModifiers) {
		// TODO Auto-generated method stub
		
	}
}
