/*
 * Created on Sep 1, 2005 6:44:49 PM
 * 
 * $Id$
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package tripleo.elijah.lang;


public class ConstantExpression extends AbstractExpression {

	public ConstantExpression(Scope aScope) {
	}
}
