/*
 * Created on Aug 30, 2005 9:05:24 PM
 * 
 * $Id$
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package tripleo.elijah.lang;

public class RegularTypeName implements TypeName {

public boolean isNull() {
	// TODO Auto-generated method stub
	return false;
}

public boolean getConstant() {
	// TODO Auto-generated method stub
	return false;
}

public void setConstant(boolean aFlag) {
	// TODO Auto-generated method stub
	
}

public boolean getReference() {
	// TODO Auto-generated method stub
	return false;
}

public void setReference(boolean aFlag) {
	// TODO Auto-generated method stub
	
}

public boolean getOut() {
	// TODO Auto-generated method stub
	return false;
}

public void setOut(boolean aFlag) {
	// TODO Auto-generated method stub
	
}

public boolean getIn() {
	// TODO Auto-generated method stub
	return false;
}

public void setIn(boolean aFlag) {
	// TODO Auto-generated method stub
	
}

public String getName() {
	// TODO Auto-generated method stub
	return null;
}

public void setName(String aS) {
	// TODO Auto-generated method stub
	
}

public void set(int aI) {
	// TODO Auto-generated method stub
	
}

public TypeName typeName(String aS) {
	// TODO Auto-generated method stub
	return null;
}

public TypeName typeof(String aS) {
	// TODO Auto-generated method stub
	return null;
}

public TypeName returnValue() {
	// TODO Auto-generated method stub
	return null;
}


private TypeModifiers tm;

public void type(TypeModifiers atm) {
tm=atm;		
}
public TypeNameList argList() {
	// TODO Auto-generated method stub
	return null;
}

public void set(TypeModifiers aModifiers) {
	// TODO Auto-generated method stub
	
}
}

