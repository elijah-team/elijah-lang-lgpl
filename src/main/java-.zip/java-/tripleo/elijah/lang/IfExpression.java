// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   IfExpression.java

package tripleo.elijah.lang;


// Referenced classes of package pak2:
//			Scope

public class IfExpression implements StatementItem {

	public IfExpression(Scope aClosure) {
	}

	public Scope scope() {
		return null;
	}

	public IExpression expr() {
		return null;
	}

	public IfExpression else_() {
		return null;
	}

	public IfExpression elseif() {
		return null;
	}
}
