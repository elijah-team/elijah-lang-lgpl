package tripleo.elijah;


/**
 * Hello world!
 *
 * @author <a href="jason@zenplex.com">Jason van Zyl</a>
 *
 */
public class App  
{

	public static void main(String args[]) {
		Main.main(args);
	}

} 
