/**
 * 
 */
package tripleo.elijah.gen.nodes;

/**
 * @author SBUSER
 *
 */
public class TmpSSACtxNode {

}
