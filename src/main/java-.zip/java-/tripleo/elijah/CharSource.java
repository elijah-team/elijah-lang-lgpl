/**
 * 
 */
package tripleo.elijah;

/**
 * @author SBUSER
 *
 */
public class CharSource {

}
