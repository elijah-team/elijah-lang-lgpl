package com.example.app;

//import com.example.dep.Dep;

public class App 
{
    public static void main( String[] args )
    {
//        Dep.hello( "GitLab" );
    }
}
